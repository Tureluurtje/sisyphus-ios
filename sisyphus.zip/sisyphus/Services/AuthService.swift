//
//  AuthService.swift
//  sisyphus
//
//  Created by Arthur Kwak on 14/06/2026.
//

import KeychainAccess
import Foundation

private enum EmailValidation {
    static let regex: NSRegularExpression? = {
        try? NSRegularExpression(
            pattern: "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        )
    }()
}

func loginService(email: String, password: String) async throws {
    do {
        // Attempt access/refresh token refresh
        let apiClient = NetworkAPIClient()

        let newTokenPair: TokenPair = try await apiClient.login(email: email, password: password)

        // Initiate keychain:
        let keychain = Keychain(service: "com.sisyphus.auth")

        keychain["access-token"] = newTokenPair.accessToken
        keychain["refresh-token"] = newTokenPair.refreshToken
        keychain["csrf-token"] = newTokenPair.csrfToken
    } catch let error as APIClientError {
        throw mapAuthError(error)
    }
}

func registerService(
    username: String,
    grade: Int,
    email: String,
    password: String
) async throws {
    do {
        
        let apiClient = NetworkAPIClient()
        
        let tokenPair = try await apiClient.register(
            username: username,
            grade: grade,
            email: email,
            password: password
        )

        let keychain = Keychain(service: "com.sisyphus.auth")
        keychain["access-token"] = tokenPair.accessToken
        keychain["refresh-token"] = tokenPair.refreshToken
        keychain["csrf-token"] = tokenPair.csrfToken

    } catch let error as APIClientError {
        throw mapAuthError(error)
    }
}

func refreshService() async throws {
    // Initiate keychain:
    let keychain = Keychain(service: "com.sisyphus.auth")
    
    // First try to get refresh and csrf token from keychain
    guard
        let refreshToken = keychain[string: "refresh-token"],
        let csrfToken = keychain[string: "csrf-token"]
    else {
        throw AuthError.missingTokens
    }
    
    // Prepare tokens
    let oldRefreshTokenPair = RefreshTokenPair(refreshToken: refreshToken, csrfToken: csrfToken)
    
    // Attempt access/refresh token refresh
    let apiClient = NetworkAPIClient()
    
    let newTokenPair: TokenPair = try await apiClient.refreshTokens(oldRefreshTokenPair: oldRefreshTokenPair)
    
    keychain["access-token"] = newTokenPair.accessToken
    keychain["refresh-token"] = newTokenPair.refreshToken
    keychain["csrf-token"] = newTokenPair.csrfToken
}

func getUserProfileService() async throws -> UserProfile {
    let networkAPIClient = NetworkAPIClient()
    
    return try await networkAPIClient.getUserProfile()
}


func pingServerService() async throws -> Bool {
    let apiClient = NetworkAPIClient()
    
    return try await apiClient.pingServerApi()
}

func logoutService() async throws {
    let keychain = Keychain(service: "com.sisyphus.auth")
    let apiClient = NetworkAPIClient()

    defer {
        keychain["access-token"] = nil
        keychain["refresh-token"] = nil
        keychain["csrf-token"] = nil
    }

    try await apiClient.logout()
}

func accountDeletionService() async throws {
    let keychain = Keychain(service: "com.sisyphus.auth")
    let apiClient = NetworkAPIClient()

    defer {
        keychain["access-token"] = nil
        keychain["refresh-token"] = nil
        keychain["csrf-token"] = nil
    }

    try await apiClient.delete()
}

func mapAuthError(_ error: APIClientError) -> AuthError {
    switch error {

    case .badServerResponse(let statusCode, let body):

        let message = body?.error.lowercased() ?? ""

        if statusCode == 422, message.contains("password") {
            return .weakPassword
        }

        guard statusCode == 409, let body else {
            return .serverMessage(body?.error ?? "Request failed")
        }

        if message.contains("username") {
            return .usernameConflict
        }

        if message.contains("email") {
            return .emailConflict
        }

        return .serverMessage(body.error)

    case .emptyResponse:
        return .unknown

    case .transportError:
        return .unknown

    case .nonHTTPResponse:
        return .unknown

    case .decodingFailed:
        return .unknown
    }
}

func isValidEmail(_ email: String) -> Bool {
    guard let regex = EmailValidation.regex else { return false }

    let range = NSRange(email.startIndex..., in: email)
    return regex.firstMatch(in: email, options: [], range: range) != nil
}
