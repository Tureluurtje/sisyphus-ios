import OSLog

func getDueWordsService(limit: Int, offset: Int) async throws -> DueWordsResponse {

    let networkAPIClient = NetworkAPIClient()

    return try await networkAPIClient.fetchDueWords(limit: limit, offset: offset)
}

func getStacksService() async throws -> GetAllStacksResponse {
    let networkAPIClient = NetworkAPIClient()

    return try await networkAPIClient.getAllStacks()
}

func submitSingleWordReview(reviewedWord: ReviewedWord) async throws {
    try await submitMultipleWordsReview(reviewedWords: [reviewedWord])
}

func submitMultipleWordsReview(reviewedWords: [ReviewedWord]) async throws {
    let networkAPIClient = NetworkAPIClient()
    
    try await networkAPIClient.submitReview(reviewedWords: reviewedWords)
}
