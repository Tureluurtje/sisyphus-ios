//
//  Untitled.swift
//  sisyphus
//
//  Created by Arthur Kwak on 14/06/2026.
//

enum AuthError: Error {
    case usernameConflict
    case emailConflict
    case invalidEmail
    case weakPassword
    case missingTokens
    case serverMessage(String)
    case unknown
}

struct APIErrorResponse: Decodable {
    let error: String
    let code: String
    let detail: String?
}
