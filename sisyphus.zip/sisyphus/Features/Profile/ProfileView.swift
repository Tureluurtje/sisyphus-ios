// ProfileView

import SwiftUI
import OSLog
import SwiftData

struct ProfileView: View {
    @State private var dailyReminderEnabled = true
    @State private var audioEnabled = false

    let userProfile: UserProfile?

    let onFinished: (AppState) -> Void

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                HStack(alignment: .top, spacing: 16) {
                    ZStack {
                        Circle()
                            .fill(
                                LinearGradient(
                                    colors: [Color.orange, Color.red.opacity(0.85)],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                            .frame(width: 76, height: 76)

                        Image(systemName: "person.fill")
                            .font(.system(size: 28, weight: .semibold))
                            .foregroundColor(.white)
                    }

                    VStack(alignment: .leading, spacing: 4) {
                        Text(userProfile?.username ?? "?")
                            .font(.title2.weight(.semibold))
                        Text("Year \(userProfile.map { String($0.grade) } ?? "?")")
                            .font(.caption)
                            .textCase(.uppercase)
                            .foregroundColor(.secondary)
                    }
                }

                VStack(alignment: .leading, spacing: 12) {
                    Text("Activity")
                        .font(.caption)
                        .textCase(.uppercase)
                        .foregroundColor(.secondary)

                    HStack {
                        ProfileStat(title: "Streak", value: "\(userProfile.map { String($0.streak) } ?? "?")")
                        ProfileStat(title: "Learned", value: "\(userProfile.map { String($0.totalWordsLearned) } ?? "?")")
                    }
                }

                SettingsView(onFinished: onFinished, userProfile: userProfile)
            }
            .padding(.horizontal, 20)
            .padding(.top, 20)
            .padding(.bottom, 20)
        }
    }
}

private struct ProfileStat: View {
    let title: String
    let value: String

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(value)
                .font(.title3.weight(.semibold))
            Text(title)
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(RoundedRectangle(cornerRadius: 16).fill(Color.secondary.opacity(0.08)))
    }
}

struct SettingsView: View {

    private let logger = Logger(
        subsystem: Bundle.main.bundleIdentifier ?? "tureluurtje.sisyphus",
        category: "SettingsView"
    )

    @EnvironmentObject var errorManager: ErrorManager
    let onFinished: (AppState) -> Void
    let userProfile: UserProfile?

    @State private var darkModeEnabled = false
    @State private var notificationsEnabled = true
    @State private var isConfirming = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 24) {
            settingsSection("Account") {
                row { LabeledContent("Username", value: userProfile?.username ?? "?") }
                divider
                row { LabeledContent("Email", value: userProfile?.email ?? "?") }
                divider
                row {
                    Button("Logout") {
                        Task { await handleLogout() }
                    }
                    .tint(.red)
                }
                divider
                row {
                    Button("Delete account") {
                        isConfirming = true
                    }
                    .confirmationDialog(
                        "Are you sure you want to logout?\nThis action is irreversible.",
                        isPresented: $isConfirming,
                        titleVisibility: .visible
                    ) {
                        Button("Continue", role: .destructive) {
                            Task { await handleAccountDeletion() }
                        }

                        Button("Cancel", role: .cancel) { }
                    }
                    .tint(.red)
                }
            }
            /*
            settingsSection("Learning") {
                row { Toggle("Notifications", isOn: $notificationsEnabled) }
                divider
                row { Toggle("Dark mode preview", isOn: $darkModeEnabled) }
            }
             */

            settingsSection("About") {
                row { LabeledContent("Credits", value: "Arthur Kwak") }
                divider
                row {
                    Link("Contact support", destination: URL(string: "mailto:tureluurtje.1@gmail.com")!)
                }
                divider
                row {
                    Link("Legal", destination: URL(string: "https://sisyphus.kwako.nl/legal")!)
                }
            }
        }
    }

    // MARK: - Building blocks
    @ViewBuilder
    private func settingsSection<Content: View>(
        _ title: String,
        @ViewBuilder content: () -> Content
    ) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.caption.weight(.semibold))
                .textCase(.uppercase)
                .foregroundColor(.secondary)

            VStack(spacing: 0) {
                content()
            }
            .background(RoundedRectangle(cornerRadius: 16).fill(Color.secondary.opacity(0.08)))
        }
    }

    private func row<Content: View>(@ViewBuilder content: () -> Content) -> some View {
        content()
            .frame(maxWidth: .infinity, minHeight: 44, alignment: .leading)
            .padding(.horizontal, 16)
            .contentShape(Rectangle())
    }

    private var divider: some View {
        Divider()
            .padding(.leading, 16)
    }

    // MARK: - Actions
    private func handleLogout() async {
        do {
            try await logoutService()
        } catch {
            errorManager.show(error.localizedDescription)
        }
        await MainActor.run {
            onFinished(.unauthenticated)
        }
    }
    
    private func handleAccountDeletion() async {
        do {
            try await accountDeletionService()
        } catch {
            errorManager.show(error.localizedDescription)
        }
        await MainActor.run {
            onFinished(.unauthenticated)
        }
    }
}

struct ProfileView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            ProfileView(userProfile: UserProfile(userId: UUID(), username: "Preview", email: "preview@apple.com", grade: 3, totalWordsLearned: 200, streak: 57, createdAt: Date(), updatedAt: Date()), onFinished: { _ in })
        }
    }
}
