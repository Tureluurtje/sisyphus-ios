//
//  ErrorManager.swift
//  sisyphus
//
//  Created by Arthur Kwak on 15/06/2026.
//

import SwiftUI
import Combine

@MainActor
final class ErrorManager: ObservableObject {

    @Published var message: String?
    @Published var isShowing: Bool = false

    func show(_ message: String) {
        self.message = message
        self.isShowing = true

        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            withAnimation {
                self.isShowing = false
            }
        }
    }
}
