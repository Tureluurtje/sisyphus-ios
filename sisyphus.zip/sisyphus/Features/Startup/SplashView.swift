//
//  SplashView.swift
//  sisyphus
//
//  Created by Arthur Kwak on 15/06/2026.
//

import SwiftUI

struct SplashView: View {

    let onFinished: (AppState) -> Void
    
    @State private var isActive = false

    var body: some View {
        VStack(spacing: 20) {
            Image("AppLogo")
                .resizable()
                .scaledToFit()
                .frame(width: 120)
                .scaleEffect(isActive ? 1 : 0.6)
                .opacity(isActive ? 1 : 0)
            
            Text("Loading")
            ProgressView()
        }
        .onAppear {
            withAnimation(.spring(duration: 0.8)) {
                isActive = true
            }
        }
        .task {
            let serverActive = await pingServer()
            if serverActive {
                await checkAuthentication()
            }
            // TODO: Load words in
        }
    }

    private func pingServer() async -> Bool {
        do {
            let serverActive: Bool = try await pingServerService()

            if !serverActive {
                await MainActor.run {
                    onFinished(.serverError)
                }
            }

            return serverActive

        } catch {
            await MainActor.run {
                onFinished(.serverError)
            }
            return false
        }
    }
    
    private func checkAuthentication() async {
        do {
            try await refreshService()

            await MainActor.run {
                onFinished(.authenticated)
            }

        } catch AuthError.missingTokens {
            await MainActor.run {
                onFinished(.unauthenticated)
            }

        } catch {
            print(error)

            await MainActor.run {
                onFinished(.unauthenticated)
            }
        }
    }
}


struct SplashView_Previews: PreviewProvider {
    static var previews: some View {
        SplashView(onFinished: { _ in })
    }
}
